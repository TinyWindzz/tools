#ifndef ARCH_X86_64_IO_H
#define ARCH_X86_64_IO_H

#include <stdint.h>
#include "../../../i386/include/arch/io.h"

#endif /* ARCH_X86_64_IO_H */
