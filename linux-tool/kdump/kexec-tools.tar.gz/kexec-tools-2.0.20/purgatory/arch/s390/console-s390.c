/*
 * S390 console code (currently not implemented)
 *
 * Copyright IBM Corp. 2011
 *
 * Author(s): Michael Holzheu <holzheu@linux.vnet.ibm.com>
 */

#include <purgatory.h>
#include "unused.h"

void putchar(int UNUSED(ch))
{
}
